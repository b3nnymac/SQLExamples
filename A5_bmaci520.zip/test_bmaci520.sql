INSERT INTO MUSICIAN (SIN, first, last, dob)
VALUES (927736221, "Dave", "Matthews", '1965-05-30'); 

UPDATE MUSICIAN
SET dob='1924-08-27'
WHERE SIN=927456221;

CALL ADD_PROF_MUSICIAN(555555555, 'Jeff', 'Tweedy', '1967-09-25', 'Drag City');

CALL MOD_MUSC_DOB(465878789, '1900-05-02');

CALL ADD_PERFORMANCE (88, 632589654, "Teeth like God's Shoeshine", "electric guitar", 'Abbey Road Studios');

-- I could not add the RECORDING_AUDIT table and therefore the record_audit_trigger